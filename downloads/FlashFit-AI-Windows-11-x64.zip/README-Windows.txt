FlashFit AI 4.4.1 - Windows 11 x64

COME SI USA

1. Estrai lo ZIP prima di avviare l'app.
2. Installa e avvia Flash Studio Desktop, Bambu Studio o una build Orca
   compatibile.
3. Tieni installato un profilo ufficiale per la stampante che vuoi usare.
4. Avvia FlashFit-AI-Windows-11.exe.
5. Controlla sempre il progetto generato, il tempo di taglio e l'anteprima
   layer prima di stampare.

I TRE STRATI DI SICUREZZA

Modello     riconosce che cosa e' il pezzo, quanto se ne guardera' la
            superficie e quali problemi tipici puo' avere.
Guardrail   decide se credergli: verifica la classe contro le misure della
            mesh e scarta quella che la geometria smentisce.
S.O.G       Security On Guardrail. Corregge il profilo finito, ricontrolla,
            e da' il via libera solo dopo l'ultima modifica. Puo' soltanto
            rallentare o raffreddare: non rende mai una stampa piu' veloce
            o piu' calda di quanto la qualita' scelta avesse gia' approvato.

Nel pannello dei controlli c'e' sempre una riga S.O.G che dice a che
punto e': in attesa, nessuna correzione necessaria, quante ne ha applicate,
oppure stampa non autorizzata. Le impostazioni e il tempo mostrati sono gia'
quelli corretti da S.O.G, non quelli di prima.

S.O.G riconosce anche i file che sono piu' oggetti saldati in un solo solido
e li separa al punto di giunzione, richiudendo le facce di taglio.

L'AI LOCALE

Non e' inclusa nell'eseguibile. Alla prima scelta di un modello l'app scarica
il motore llama.cpp e i pesi in %APPDATA%\FlashFitAI\models, mostrando la
percentuale; il download riprende da dove si era interrotto. Tutto gira
offline su CPU, senza GPU.

Due modelli disponibili:
  Leggera  Qwen2.5 1.5B Q4  circa 1,0 GB  gira ovunque
  Potente  Qwen2.5 3B Q4    circa 2,0 GB  vuole piu' memoria

Il modello non decide nessun numero: i parametri sono calcolati dal
programma. Il modello dice che cosa e' l'oggetto, e nel caso peggiore in cui
sbagli il risultato e' una stampa piu' prudente del necessario.

COSA SUPPORTA

20 famiglie di stampanti: 6 Flashforge e 14 Bambu Lab, ognuna con i suoi
ugelli rilevati separatamente. L'altezza layer viene adattata all'ugello
montato: un ugello da 0,8 mm non puo' stampare a 0,12 mm, e l'app lo dice
invece di provarci.
55 profili filamento su PLA, PETG, ABS/ASA, TPU e supporti solubili.

SE L'APP SI CHIUDE DA SOLA

Da questa versione ogni errore fatale viene scritto in
%APPDATA%\FlashFitAI\flashfit.log prima che il processo termini. Se la
finestra sparisce, allega quel file nella segnalazione: contiene il punto
esatto in cui e' successo.

NOTE

L'eseguibile non e' ancora firmato Authenticode, quindi Windows SmartScreen
mostrera' "editore sconosciuto". Scarica solo dal repository ufficiale e
confronta l'impronta del file con SHA256SUMS.txt.

Beta: verifica sempre il risultato prima di avviare una stampa.

https://github.com/alexmark53343-byte/FlashFit-AI

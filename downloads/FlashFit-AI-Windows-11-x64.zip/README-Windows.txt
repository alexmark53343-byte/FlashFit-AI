FlashFit AI 4.3.0 Multi-Printer Engineering Beta
Windows 11 x64

1. Extract the ZIP before running the app.
2. Install and start Flash Studio Desktop, Bambu Studio, or a compatible Orca build.
3. Keep an official 0.4 mm profile installed for the printer you want to use.
4. Run FlashFit-AI-Windows-11.exe.
5. Always inspect the generated project, sliced time, and layer preview before printing.

This beta supports 20 current printer families: 6 Flashforge and 14 Bambu Lab.
It preserves vendor machine G-code, retraction, Flow Dynamics/Pressure Advance,
purge, wipe, tool-change, and calibration behavior.

The executable is not yet Authenticode-signed. Windows SmartScreen can therefore
show Unknown publisher. Download only from the official FlashFit-AI GitHub repository
and compare the executable with SHA256SUMS.txt.

Project documentation:
https://github.com/alexmark53343-byte/FlashFit-AI

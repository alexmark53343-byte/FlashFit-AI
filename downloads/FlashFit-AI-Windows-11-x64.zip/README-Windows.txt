FlashFit AI 4.3.0 - Windows 11 x64

COME SI USA

1. Estrai lo ZIP prima di avviare l'app.
2. Installa e avvia Flash Studio Desktop, Bambu Studio o una build Orca
   compatibile.
3. Tieni installato un profilo ufficiale per la stampante che vuoi usare.
4. Avvia FlashFit-AI-Windows-11.exe.
5. Controlla sempre il progetto generato, il tempo di taglio e l'anteprima
   layer prima di stampare.

L'AI LOCALE

Non e' inclusa nell'eseguibile. Alla prima scelta di un modello l'app scarica
il motore llama.cpp e i pesi in %APPDATA%\FlashFitAI\models, mostrando la
percentuale; il download riprende da dove si era interrotto. Tutto gira
offline su CPU, senza GPU.

Due modelli disponibili:
  Leggera  Qwen2.5 1.5B Q4  circa 1,0 GB  gira ovunque
  Potente  Qwen2.5 3B Q4    circa 2,0 GB  vuole piu' memoria

La scelta non cambia la qualita' di stampa: i parametri sono calcolati dal
programma, il modello dice soltanto che cosa e' l'oggetto.

COSA SUPPORTA

20 famiglie di stampanti: 6 Flashforge e 14 Bambu Lab, ognuna con i suoi
ugelli rilevati separatamente.
55 profili filamento su PLA, PETG, ABS/ASA, TPU e supporti solubili.

NOTE

L'eseguibile non e' ancora firmato Authenticode, quindi Windows SmartScreen
mostrera' "editore sconosciuto". Scarica solo dal repository ufficiale e
confronta l'impronta del file con SHA256SUMS.txt.

Beta: verifica sempre il risultato prima di avviare una stampa.

https://github.com/alexmark53343-byte/FlashFit-AI

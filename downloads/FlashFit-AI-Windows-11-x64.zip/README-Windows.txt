FlashFit AI 4.2.1 Stability Fix Beta

This build fixes Windows UI stalls caused by continuous full-window repainting,
per-frame backbuffer allocation, and unbounded graphical caches during resize.

The package includes an SHA-256 checksum. This test beta is not yet signed with
an Authenticode certificate, so Windows SmartScreen may still show "Unknown
publisher". Download only from the official FlashFit-AI GitHub repository.

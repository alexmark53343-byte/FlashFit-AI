FLASHFIT AI 3.6 BETA - WINDOWS 11 x64

Italian independent project developed by one developer.

INSTALLATION
1. Extract the complete ZIP archive.
2. Run FlashFit-AI-Windows-11.exe.
3. Drop or choose an STL, OBJ or 3MF model.
4. Select print mode and filament.
5. Build the profile and inspect it in Flash Studio before printing.

CURRENT SUPPORT
- Windows 11 x64
- Flashforge Adventurer 5M, 0.4 mm nozzle
- Single-color / single-extruder printing
- PLA, PETG, ABS and TPU

This is a public beta. Windows SmartScreen may show a warning because this
independent beta does not yet have a commercial code-signing certificate.
Choose "More info" and "Run anyway" only when the file was downloaded from
the official FlashFit-AI GitHub repository.

The application and intelligent profile engine remain proprietary.
